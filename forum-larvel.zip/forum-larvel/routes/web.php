<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/logout', function () {
    Auth::logout();
    return redirect('login');
});

Route::get('/welcome', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/index', function () {
    return view('master');
});
Route::get('/test', function () {
    return view('test');
});

Route::get('/faqadmin', function () {
    return view('faqadmin');
});


Route::post('/test/submit', 'TestController@submit');

Route::resource('route', 'MyController' );

Route::post('/faq/admin', 'faqController@submit');

Route::post('/faq/displayDeveloper', 'faqController@displayDeveloper');

Route::post('/faq/displayFaq', 'faqController@displayPublic');

Route::post('/faq/displayAdminFaq', 'faqController@displayAdmin');

Route::post('/faq/rejectFaq', 'faqController@rejectFaq');

Route::post('/faq/acceptFaq', 'faqController@acceptFaq');
