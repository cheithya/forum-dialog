
@if (count($faqs) === 0)
    <h1>No records found to Approve</h1>
@else

    @foreach($faqs as $faq)
        {!! Form::open(['url' => 'faq/acceptFaq']) !!}
        <h1>Title  : {{ $faq->title}} </h1>
        <h3>Description  :{{ $faq->description}} </h3>
        <h5>Created At :{{ $faq->created_at}} </h5>
        <h3>Approved State :{{ $faq->approvedState}} </h3>
        <input type="hidden" name="country" value="{{ $faq->id}}">
        {{ Form::submit('Approve ')}}</br>
        {!! Form::close() !!}

        {!! Form::open(['url' => 'faq/rejectFaq']) !!}
        <input type="hidden" name="country" value="{{ $faq->id}}">
        {{ Form::submit('Reject ')}}</br>
        {!! Form::close() !!}
    @endforeach
@endif
