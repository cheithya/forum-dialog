
<link rel="stylesheet" type="text/css" href="../css/main.css">
<link rel="stylesheet" type="text/css" href="../css/main-dialog.css">
<link rel="stylesheet" type="text/css" href="../css/main-xl.css">
<!--<link rel="stylesheet" type="text/css" href="resources/css/main-ncell.css">-->
<!--<link rel="stylesheet" type="text/css" href="resources/css/main-smart.css">-->
<!--<link rel="stylesheet" type="text/css" href="resources/css/main-robi.css">-->
<link rel="stylesheet" type="text/css" href="../css/main-celcom.css">
<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="../css/animations.css">