@if(count($errors)  > 0 )
@foreach($errors->all() as $error)
<!-- error message goes here -->
  {{$error}}
@endforeach
@endif

{!! Form::open(['url' => 'test/submit']) !!}

    {{ Form::label('did', 'Developer ID')}}
    {{ Form::text('did', 'Enter Developer ID')}}</br>

    {{ Form::label('pid', 'Product ID')}}
    {{ Form::text('pid', 'Enter Product ID')}}</br>

    {{ Form::label('title', 'Title ')}}
    {{ Form::text('title', 'Enter title')}}</br>

    {{ Form::label('description', 'Description')}}
    {{ Form::text('description', 'Enter Description')}}</br>

    {{ Form::submit('Submit FAQ')}}</br>

{!! Form::close() !!}
