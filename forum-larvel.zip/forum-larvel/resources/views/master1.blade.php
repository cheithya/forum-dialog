<!DOCTYPE html>
<html >
<header>
    @yield('css')
</header>
<body>
    @yield('js')
</body>
<footer>
    @yield('css')
</footer>
</html>