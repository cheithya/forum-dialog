
@if (count($faqs) === 0)
    <h1>No records found </h1>
@else

    @foreach($faqs as $faq)

        <h1>Title  : {{ $faq->title}} </h1>
        <h3>Description  :{{ $faq->description}} </h3>
        <h5>Created At :{{ $faq->created_at}} </h5>

    @endforeach

@endif
