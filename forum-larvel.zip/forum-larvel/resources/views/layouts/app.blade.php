<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>IOT-FORUM</title>

    <!-- Styles -->

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    @yield('css')


</head>
<body>



    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">

                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <div class="navbar-brand-logo">
                            <img src="../images/header-logo-dialog.png" height="60px" alt="">
                        </div>
                    </a>
                </div>
                <div class="collapse navbar-collapse navbar-responsive-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.php">Home</a></li>
                        <!--                    <li><a href="#">Products</a></li>-->
                        <!--                    <li><a href="#">Resources</a></li>-->
                        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Resources <b
                                        class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="http://docs.iot.ideamart.io/" target="_blank">Developer</a></li>
                                <li><a href="http://docs.iot.ideamart.io/" target="_blank">Consumer</a></li>
                                <li><a href="http://docs.iot.ideamart.io/" target="_blank">Enterprise</a></li>
                            </ul>
                        </li>
                        <!--                    <li><a href="#">Testimonials</a></li>-->
                        <!--                    <li><a href="#">IOT Power Forum</a></li>-->
                        <!--                    <li><a href="#">Support</a></li>-->
                        <li><a href="contactus.php">Contact Us</a></li>
                        <!-- <li><a href="{{ url('register?t=d') }}"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li> -->
                        <!-- <li><a href="{{ route('login') }}"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
                    </ul>


                    <!-- Branding Image -->
                    <a class="navbar-brand" href="{{ url('/') }}">

                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @guest
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <li><a href="{{ route('register') }}">Register</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="{{ route('logout') }}">
                                            Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>


        @yield('content')
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    @yield('js')
    @include('master')
</body>
</html>
