
@if (count($faqs) === 0)
    <h1>No records found </h1>
@else
    //accepted

    @foreach($faqs as $faq)
        @if($faq->approvedState === 'true')
        <h1>Title  : {{ $faq->title}} </h1>
        <h3>Description  :{{ $faq->description}} </h3>
        <h3>Approved State :{{ $faq->approvedState}} </h3>
        <h5>Created At :{{ $faq->created_at}} </h5>

        @endif
    @endforeach
    //rejected
    @foreach($faqs as $faq)
        @if($faq->approvedState === 'rejected')
            <h1>Title  : {{ $faq->title}} </h1>
            <h3>Description  :{{ $faq->description}} </h3>
            <h3>Approved State :{{ $faq->approvedState}} </h3>
            <h5>Created At :{{ $faq->created_at}} </h5>

        @endif
    @endforeach
    //pending
    @foreach($faqs as $faq)
        @if($faq->approvedState === 'false')
            <h1>Title  : {{ $faq->title}} </h1>
            <h3>Description  :{{ $faq->description}} </h3>
            <h3>Approved State :{{ $faq->approvedState}} </h3>
            <h5>Created At :{{ $faq->created_at}} </h5>

        @endif
    @endforeach
@endif
