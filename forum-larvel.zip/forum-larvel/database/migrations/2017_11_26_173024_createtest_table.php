<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatetestTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('testTable', function (Blueprint $table) {
            $table->increments('faqid');
            $table->timestamps();
            $table->bigInteger('did');
            $table->bigInteger('pid');
            $table->string('title');
            $table->string('description');



        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('CreatetestTable');
    }
}
