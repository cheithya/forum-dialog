
<?php if(count($faqs) === 0): ?>
    <h1>No records found </h1>
<?php else: ?>

    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <h1>Title  : <?php echo e($faq->title); ?> </h1>
        <h3>Description  :<?php echo e($faq->description); ?> </h3>
        <h5>Created At :<?php echo e($faq->created_at); ?> </h5>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
