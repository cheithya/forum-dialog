<html>
<header><title></title>

<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>
<link rel="stylesheet" type="text/css" href="resources/css/main.css">
<link rel="stylesheet" type="text/css" href="resources/css/main-dialog.css">
<link rel="stylesheet" type="text/css" href="resources/css/main-xl.css">
<!--<link rel="stylesheet" type="text/css" href="resources/css/main-ncell.css">-->
<!--<link rel="stylesheet" type="text/css" href="resources/css/main-smart.css">-->
<!--<link rel="stylesheet" type="text/css" href="resources/css/main-robi.css">-->
<link rel="stylesheet" type="text/css" href="resources/css/main-celcom.css">
<link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="resources/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="resources/css/animations.css">
<body>
<nav class="navbar navbar-inverse navbar-fixed-top navbar-shrink">
    <div class="container">
        <div class="navbar-header page-scroll">
            <button type="button" class="navbar-toggle" data-toggle="collapse"
                    data-target=".navbar-responsive-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">
                <div class="navbar-brand-logo">
                    <!--                        <img src="resources/images/tenant/header-logo-dialog.png" height="60px" alt="">-->
                </div>
            </a>
        </div>
        <div class="collapse navbar-collapse navbar-responsive-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php">Home</a></li>
                <!--                    <li><a href="#">Products</a></li>-->
                <!--                    <li><a href="#">Resources</a></li>-->
                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Resources <b
                                class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="http://docs.iot.ideamart.io/" target="_blank">Developer</a></li>
                        <li><a href="http://docs.iot.ideamart.io/" target="_blank">Consumer</a></li>
                        <li><a href="http://docs.iot.ideamart.io/" target="_blank">Enterprise</a></li>
                    </ul>
                </li>
                <!--                    <li><a href="#">Testimonials</a></li>-->
                <!--                    <li><a href="#">IOT Power Forum</a></li>-->
                <!--                    <li><a href="#">Support</a></li>-->
                <li class="active"><a href="contactus.php">Contact Us</a></li>
                <!-- <li><a href="<?php echo e(url('register?t=d')); ?>"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li> -->
                <!-- <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-lg-12 col-sm-12 text-center middle-container-05-header">
            
        </div>
    </div>
</div>
<!-- Nav End -->
</header>
<div class="middle-container other">
    <div class="middle-container-05 animatedParent" id="contact_us">
        <div class="row">
            <div class="col-sm-3 middle-container-05-left text-left">



                    <?php if(count($errors)  > 0 ): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- error message goes here -->
                            <?php echo e($error); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => 'faq/admin']); ?>


                   <div> <?php echo e(Form::label('title', 'Title ')); ?>

                    <?php echo e(Form::text('title', null)); ?>

                    <div></div><?php echo e(Form::label('description', 'Description')); ?>

                    <?php echo e(Form::text('description', null)); ?></br>
                    <?php echo e(Form::submit('Submit FAQ')); ?></div>
                    <?php echo Form::close(); ?>




                    <?php echo Form::open(['url' => 'faq/displayDeveloper']); ?>

                    <?php echo e(Form::submit('View FAQ Developer')); ?></br>
                    <?php echo Form::close(); ?>




                    <?php echo Form::open(['url' => 'faq/displayFaq']); ?>

                    <?php echo e(Form::submit('View FAQ public')); ?></br>
                    <?php echo Form::close(); ?>


                    <?php echo Form::open(['url' => 'faq/displayAdminFaq']); ?>

                    <?php echo e(Form::submit('View FAQ Admin')); ?></br>
                    <?php echo Form::close(); ?>


                </div>
            </div>
            <div class="col-sm-3 middle-container-05-right">
                <img class="animated fadeInLeft" src="../images/contact_right.png" width="100%">
            </div>
        </div>
    </div>

</body>

    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-3 main-footer-content">
                    <h3>Stay Connected</h3>
                    <ul>
                        <li><a href="https://www.facebook.com/groups/ideamartlk/" target="_blank"><img
                                        src="../images/f_facebook.png" width="28px"
                                        height="28px">Facebook</a></li>
                        <li><a href="https://twitter.com/dialog_iot" target="_blank"><img
                                        src="../images/f_twitter.png"
                                        width="28px" height="28px">Twitter</a>
                        </li>
                        <li><a href="https://www.youtube.com/user/IdeaMartLK/videos" target="_blank"><img
                                        src="../images/f_youtube.png" width="28px" height="28px">Youtube</a>
                        </li>
                        <li><a href="https://github.com/dialogiot" target="_blank"><img
                                        src="../images/f_github.png" width="28px"
                                        height="28px">Github</a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-3 main-footer-content">
                    <h3>Support</h3>
                    <ul>
                        <li><a href="http://docs.iot.ideamart.io/" target="_blank">Documentation</a></li>
                        <!--                        <li><a href="#">Video Tutorials</a></li>-->
                        <!--                        <li><a href="#">IOT Power Forum</a></li>-->
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-3 main-footer-content">
                    <h3>Developer Community</h3>
                    <ul>
                        <li><a href="#">Request an Event</a></li>
                        <li><a href="http://docs.iot.ideamart.io/" target="_blank">Code Samples</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-3 main-footer-content">
                    <h3>Useful links</h3>
                    <ul>
                        <li><a href="http://www.ideamart.lk/" target="_blank">Ideamart</a></li>
                        <li><a href="https://www.ideabiz.lk/store/" target="_blank">Ideabiz</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
</div>
</footer>
</html>