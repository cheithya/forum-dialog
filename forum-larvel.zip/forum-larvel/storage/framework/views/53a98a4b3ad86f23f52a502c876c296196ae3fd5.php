
<div></div>

<footer class="main-footer">

        <div class="row">
            <div class="col-lg-3 col-sm-3 main-footer-content">
                <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <h3>Stay Connected</h3>
                <ul>
                    <li><a href="https://www.facebook.com/groups/ideamartlk/" target="_blank"><img
                                    src="../images/f_facebook.png" width="28px"
                                    height="28px">Facebook</a></li>
                    <li><a href="https://twitter.com/dialog_iot" target="_blank"><img
                                    src="../images/f_twitter.png"
                                    width="28px" height="28px">Twitter</a>
                    </li>
                    <li><a href="https://www.youtube.com/user/IdeaMartLK/videos" target="_blank"><img
                                    src="../images/f_youtube.png" width="28px" height="28px">Youtube</a>
                    </li>
                    <li><a href="https://github.com/dialogiot" target="_blank"><img
                                    src="../images/f_github.png" width="28px"
                                    height="28px">Github</a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-3 col-sm-3 main-footer-content">
                <h3>Support</h3>
                <ul>
                    <li><a href="http://docs.iot.ideamart.io/" target="_blank">Documentation</a></li>
                    <!--                        <li><a href="#">Video Tutorials</a></li>-->
                    <!--                        <li><a href="#">IOT Power Forum</a></li>-->
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-sm-3 main-footer-content">
                <h3>Developer Community</h3>
                <ul>
                    <li><a href="#">Request an Event</a></li>
                    <li><a href="http://docs.iot.ideamart.io/" target="_blank">Code Samples</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-sm-3 main-footer-content">
                <h3>Useful links</h3>
                <ul>
                    <li><a href="http://www.ideamart.lk/" target="_blank">Ideamart</a></li>
                    <li><a href="https://www.ideabiz.lk/store/" target="_blank">Ideabiz</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>