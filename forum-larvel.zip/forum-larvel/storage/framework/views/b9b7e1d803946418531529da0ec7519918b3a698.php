
<?php if(count($faqs) === 0): ?>
    <h1>No records found to Approve</h1>
<?php else: ?>

    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo Form::open(['url' => 'faq/acceptFaq']); ?>

        <h1>Title  : <?php echo e($faq->title); ?> </h1>
        <h3>Description  :<?php echo e($faq->description); ?> </h3>
        <h5>Created At :<?php echo e($faq->created_at); ?> </h5>
        <h3>Approved State :<?php echo e($faq->approvedState); ?> </h3>
        <input type="hidden" name="country" value="<?php echo e($faq->id); ?>">
        <?php echo e(Form::submit('Approve ')); ?></br>
        <?php echo Form::close(); ?>


        <?php echo Form::open(['url' => 'faq/rejectFaq']); ?>

        <input type="hidden" name="country" value="<?php echo e($faq->id); ?>">
        <?php echo e(Form::submit('Reject ')); ?></br>
        <?php echo Form::close(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
