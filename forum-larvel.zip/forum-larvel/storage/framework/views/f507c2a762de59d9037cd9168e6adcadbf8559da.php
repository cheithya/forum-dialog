
<?php if(count($faqs) === 0): ?>
    <h1>No records found </h1>
<?php else: ?>
    //accepted

    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($faq->approvedState === 'true'): ?>
        <h1>Title  : <?php echo e($faq->title); ?> </h1>
        <h3>Description  :<?php echo e($faq->description); ?> </h3>
        <h3>Approved State :<?php echo e($faq->approvedState); ?> </h3>
        <h5>Created At :<?php echo e($faq->created_at); ?> </h5>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    //rejected
    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($faq->approvedState === 'rejected'): ?>
            <h1>Title  : <?php echo e($faq->title); ?> </h1>
            <h3>Description  :<?php echo e($faq->description); ?> </h3>
            <h3>Approved State :<?php echo e($faq->approvedState); ?> </h3>
            <h5>Created At :<?php echo e($faq->created_at); ?> </h5>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    //pending
    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($faq->approvedState === 'false'): ?>
            <h1>Title  : <?php echo e($faq->title); ?> </h1>
            <h3>Description  :<?php echo e($faq->description); ?> </h3>
            <h3>Approved State :<?php echo e($faq->approvedState); ?> </h3>
            <h5>Created At :<?php echo e($faq->created_at); ?> </h5>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
