<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Test;

class TestController extends Controller
{
    public function submit(Request $request){
      $this->validate($request,[
        'did' => 'required',
        'pid' => 'required',
        'title' => 'required',
        'description' => 'required'

      ]);
    $tt = new  Test;
      $tt->did =  '1';
      $tt->pid =  '1';
      $tt->title =  $request->input('title');
      $tt->description =  $request->input('description');
      $tt->save();
      return redirect('/');;


    }
}


