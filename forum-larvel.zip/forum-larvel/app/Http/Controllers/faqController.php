<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Faq;
class faqController extends Controller
{
    //
    public function submit(Request $request){
      $this->validate($request,[
        'title' => 'required',
        'description' => 'required'
      ]);
      $faq = new  Faq;
      //assign developer id from the session
      $faq->devloperId =  '1';
      //assign product id from the session
      $faq->productId =  '1';
      $faq->approvedState = 'false';
      $faq->title =  $request->input('title');
      $faq->description =  $request->input('description');
      $faq->save();
      return  redirect()->action(
            'faqController@displayDeveloper'
        );
//      return redirect('/faq/displayDeveloper');
    }


    public function displayDeveloper(){
//        //assign developer id from the session
        $devloperId = 1;
        //assign developer id from the session
        $productId = 1;
        $matchThese = ['devloperId' => $devloperId, 'productId' => $productId  ];
        $faqs = Faq::where($matchThese)
            ->get();
        return view('viewfaqdevloper')->with('faqs',$faqs);
    }

    public function displayPublic(){
        //assign developer id from the session
        $productId = 1;
        $matchThese = ['approvedState' => 'true', 'productId' => $productId];
        $faqs = Faq::where($matchThese)
            ->get();
        return view('viewfaq')->with('faqs',$faqs);
    }

    public function displayAdmin(){
        //assign developer id from the session

        $matchThese = ['approvedState' => 'false'];
        $faqs = Faq::where($matchThese)
            ->get();
        return view('viewfaqadmin')->with('faqs',$faqs);
    }

    public function rejectFaq( Request $request ){
        //assign developer id from the session
        $id=  $request->input('id');
        $faq =Faq::find(1);
        $faq->approvedState = 'reject';
        $faq->save();

    }

    public function acceptFaq(Request $request){
        //assign developer id from the session
        $id=  $request->input('id');
        $faq =Faq::find(1);
        $faq->approvedState = 'true';
        $faq->save();

    }

}
